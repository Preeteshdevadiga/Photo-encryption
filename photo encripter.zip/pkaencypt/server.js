const express = require('express');
const bodyParser = require('body-parser');
const CryptoJS = require('crypto-js');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 4005;

// Middleware
app.use(cors());
app.use(bodyParser.json({ limit: '50mb' })); // Handle large payloads for Base64 images
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files

// Route for encryption
app.post('/encrypt', (req, res) => {
    const { imageBase64, password } = req.body;

    if (!imageBase64 || !password) {
        return res.status(400).json({ error: 'Image and password are required.' });
    }

    try {
        const encrypted = CryptoJS.AES.encrypt(imageBase64, password).toString();
        res.json({ encryptedImage: encrypted });
    } catch (error) {
        res.status(500).json({ error: 'Encryption failed.', details: error.message });
    }
});

// Route for decryption
app.post('/decrypt', (req, res) => {
    const { encryptedImage, password } = req.body;

    if (!encryptedImage || !password) {
        return res.status(400).json({ error: 'Encrypted image and password are required.' });
    }

    try {
        const bytes = CryptoJS.AES.decrypt(encryptedImage, password);
        const decrypted = bytes.toString(CryptoJS.enc.Utf8);

        if (!decrypted) {
            return res.status(400).json({ error: 'Invalid password or corrupted data.' });
        }

        res.json({ decryptedImage: decrypted });
    } catch (error) {
        res.status(500).json({ error: 'Decryption failed.', details: error.message });
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
