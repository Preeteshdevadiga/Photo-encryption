let form = document.querySelector('#form');
let fileInput = document.querySelector('#file');
let passwordInput = document.querySelector('#password');
let originalImagePreview = document.querySelector('#originalImagePreview');
let encryptedImagePreview = document.querySelector('#encryptedImagePreview');
let decryptedImagePreview = document.querySelector('#decryptedImagePreview');
let downloadEncryptedImageButton = document.querySelector('#downloadEncryptedImage');
let downloadDecryptedImageButton = document.querySelector('#downloadDecryptedImage');

let encrypt = (plainText, password) => {
    return CryptoJS.AES.encrypt(plainText, password).toString();
};

let decrypt = (cipherText, password) => {
    let bytes = CryptoJS.AES.decrypt(cipherText, password);
    return bytes.toString(CryptoJS.enc.Utf8);
};

let prepareDownload = (data, filename, button) => {
    let blob = new Blob([data], { type: 'text/plain' });
    let url = URL.createObjectURL(blob);
    button.onclick = () => {
        let a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
    };
};

let handleImageEncryption = (file, password) => {
    let reader = new FileReader();
    reader.onload = function () {
        // Step 1: Convert the image to a Base64 string
        let base64Image = reader.result.split(',')[1];
        originalImagePreview.src = reader.result;

        // Step 2: Encrypt the Base64 string
        let encryptedString = encrypt(base64Image, password);

        // Step 3: Prepare encrypted data for download
        prepareDownload(encryptedString, 'encrypted_image.txt', downloadEncryptedImageButton);

        // Step 4: Simulate an encrypted preview by generating a blurred placeholder
        let scrambledBase64 = base64Image.split('').reverse().join('');
        encryptedImagePreview.src = `data:image/png;base64,${scrambledBase64}`;

        // Step 5: Decrypt the encrypted string
        let decryptedBase64 = decrypt(encryptedString, password);
        if (decryptedBase64) {
            decryptedImagePreview.src = `data:image/png;base64,${decryptedBase64}`;
            prepareDownload(decryptedBase64, 'decrypted_image.png', downloadDecryptedImageButton);
        } else {
            alert('Decryption failed. Check your password.');
        }
    };
    reader.readAsDataURL(file);
};

form.addEventListener('submit', (event) => {
    event.preventDefault();
    const file = fileInput.files[0];
    const password = passwordInput.value.trim();

    if (!file || !password) {
        alert('Please provide both an image and a password.');
        return;
    }

    handleImageEncryption(file, password);
});
